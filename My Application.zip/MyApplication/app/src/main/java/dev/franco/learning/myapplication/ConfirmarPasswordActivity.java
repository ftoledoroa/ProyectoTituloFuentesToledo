package dev.franco.learning.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class ConfirmarPasswordActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmar_password);
        // llamar a dos widgets
        Button btnConfirmar = findViewById(R.id.btConfirmar);
        EditText etRePassword = findViewById(R.id.etRePassword);
        EditText etPassword = findViewById(R.id.etPassword);

        btnConfirmar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Password = etPassword.getText().toString();
                String RePassword = etRePassword.getText().toString();

                if(Password.equals("") || RePassword.equals("")) {
                    Toast.makeText(getApplicationContext(),"Hay campos vacios", Toast.LENGTH_LONG).show();
                    return;
                }
                if(Password.equals(RePassword)){
                    Toast.makeText(getApplicationContext(),"Contraseña cambiada con exito", Toast.LENGTH_LONG).show();
                    Intent i = new Intent(ConfirmarPasswordActivity.this,HomeActivity.class);
                    startActivity(i);
                    return;
                }
                Toast.makeText(getApplicationContext(),"Las contraseñas deben ser identicas", Toast.LENGTH_LONG).show();

            }
        });
    }
}
package dev.franco.learning.myapplication;

import androidx.annotation.RequiresFeature;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // llamar a dos widgets
        Button btnIngresar = findViewById(R.id.btIniciarSesion);
        TextView tvTitulo = findViewById(R.id.tvTitulo);
        EditText etUsuario = findViewById(R.id.etUsuario);
        EditText etPassword = findViewById(R.id.etPassword);
        TextView tvRecuperar = findViewById(R.id.tvOlvidopassword);

        btnIngresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String usuario = etUsuario.getText().toString();
                String pass = etPassword.getText().toString();

                if(usuario.equals("")|| pass.equals((""))){
                    Toast.makeText(getApplicationContext(),"Ingrese todos los Campos", Toast.LENGTH_LONG).show();
                    return;
                }

                Intent i = new Intent(MainActivity.this,HomeActivity.class);

                startActivity(i);
            }
        });
        tvRecuperar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this,ConfirmarPasswordActivity.class);
                startActivity(i);
            }

        });
    }
}

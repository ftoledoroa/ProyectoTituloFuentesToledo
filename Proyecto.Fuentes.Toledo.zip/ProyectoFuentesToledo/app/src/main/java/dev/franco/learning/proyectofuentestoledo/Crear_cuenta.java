package dev.franco.learning.proyectofuentestoledo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Crear_cuenta extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crear_cuenta);
    }
}